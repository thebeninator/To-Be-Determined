import ColourBand from "./ColourBand";

function DaySlot({events, schedule}) {
  const hasEvents = events === null || events.length === 0;

  return <div>
    <ColourBand />
    <p style={hasEvents ? null: {backgroundColor: "yellow"}}> 
      {hasEvents ? "[No events]" : `Events: ${events.length}`}
    </p>
  </div>
}

export default DaySlot;
