import { secondsToHHMM } from "../Utility";

const eventStyle = {
  paddingBottom: "15px", 
  width: "fit-content",
}

function renderEvents(events) {
  return (
    events.map((event, idx) => {
      return <div key={idx} style={eventStyle}>
        <h4>
          {secondsToHHMM(event.timeRange[0])} - {secondsToHHMM(event.timeRange[1])}: {event.name}
        </h4>        
        <p style={{whiteSpace: "pre-line"}}>{event.description}</p>
      </div>
    }) 
  )
}

function DayInspector({date, events}) {
  return (<div>
    {date === null ? 
    <h2>No day selected</h2> 
    : 
    <>
      <h2 title="hee">{date.toDateString()}</h2>

      <div>
        <h3>Events</h3>
        {events === null || events.length === 0 ? "No events" : renderEvents(events)}
      </div>
    </>}
  </div>);
}

export default DayInspector;
