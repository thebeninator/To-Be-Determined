import Calendar from "react-calendar";
import DaySlot from "./DaySlot";
import { useEffect, useLayoutEffect, useState } from "react";
import { getEventsOnDay, hashDate } from "../Utility";
import User from "../obj/DummyUser";
import DayInspector from "./DayInspector";

const MONTHS = [
  "January", "February", "March", 
  "April", "May", "June",
  "July", "August", "September", 
  "October", "November", "December"
];

function TBDCalendar() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedDateEvents, setSelectedDateEvents] = useState({});
  const [month, setMonth] = useState(0);
  const [year, setYear] = useState(0);
  const [dayInspectorActive, setDayInspectorActive] = useState(true);
  const [weeklySchedulerActive, setWeeklySchedulerActive] = useState(false);
  const [eventPlannerActive, setEventPlannerActive] = useState(false);

  useLayoutEffect(() => {
    var date = new Date();
    setMonth(date.getMonth());
    setYear(date.getFullYear());
  }, []);

  return (<>    
    <div style={{padding: "80px"}}>
      <h1>
        {MONTHS[month]}, {year}
      </h1>

      <Calendar
        showNavigation = {false}
        showNeighboringMonth = {false}
        tileContent = {({view, date}) => {
          if (view === 'month') {
            const events = getEventsOnDay(User, date);
            return <DaySlot events = {events} />
          }

          return null;
        }}

        onClickDay = {(date) => {
          const oldDateHash = hashDate(selectedDate);
          const sameDate = oldDateHash === hashDate(date);
        
          setSelectedDate(sameDate ? null : date);
          setSelectedDateEvents(sameDate ? null : getEventsOnDay(User, date));
        }}
      />
    </div>

    <div>
      <div>
        <button>Day Inspector</button>
        <button>Weekly Scheduler</button>
        <button>Event Planner</button>
      </div>

      {dayInspectorActive && <DayInspector date={selectedDate} events={selectedDateEvents} />}
    </div>
  </>);
}

export default TBDCalendar;